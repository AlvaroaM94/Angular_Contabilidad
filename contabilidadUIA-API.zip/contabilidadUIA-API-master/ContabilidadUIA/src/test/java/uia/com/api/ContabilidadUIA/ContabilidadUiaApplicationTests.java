package uia.com.api.ContabilidadUIA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContabilidadUiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
